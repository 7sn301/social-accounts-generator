# مولد معلومات حسابات التواصل الاجتماعي

يدعم:
- X / Twitter
- Instagram
- YouTube
- Facebook
- Snapchat

## صيغة Excel المطلوبة

| platform | username |
|---|---|
| x | nasa |
| instagram | natgeo |
| youtube | MrBeast |
| facebook | Meta |
| snapchat | snapchat |

## التشغيل عبر Streamlit Cloud

1. ارفع الملفات إلى GitHub.
2. افتح Streamlit Cloud.
3. اختر New app.
4. اختر المستودع.
5. اجعل Main file path هو:
   app.py
6. اضغط Deploy.